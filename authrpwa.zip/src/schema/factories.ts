import type { TourDraft } from './draft';
import type { TourEntry, TourLocaleContent } from './tour';
import type { RiddleEntry, RiddleLocaleContent } from './riddle';
import { LOCALES, type Locale } from './locales';
import { emptyAcceptedAnswers } from './riddle';
import { createDefaultTourMeta } from './tourMeta';
import {
  buildDraftStationAssetPaths,
  DEFAULT_STATION_VISUAL,
} from '@/stations/visuals';

export function createId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}-${Date.now().toString(36)}-${rand}`;
}

export function emptyTourLocale(): TourLocaleContent {
  return {
    title: '',
    location: '',
    duration: '',
    description: [],
    introSection: [],
    outroSection: [],
    welcomeMessage: '',
  };
}

export function emptyRiddleLocale(): RiddleLocaleContent {
  return {
    location: '',
    firstSection: [],
    historySection: [],
    riddleSection: [],
    successSection: [],
    hints: [],
  };
}

function localeMap<T>(factory: () => T): Record<Locale, T> {
  return LOCALES.reduce(
    (acc, locale) => {
      acc[locale] = factory();
      return acc;
    },
    {} as Record<Locale, T>,
  );
}

export function emptyTour(id: string): TourEntry {
  const meta = createDefaultTourMeta();
  return {
    id,
    number: 0,
    imagePath: '',
    riddlesPath: `${id}/riddles.json`,
    distance: '',
    unlocked: true,
    ...localeMap(emptyTourLocale),
    publicMeta: meta.publicMeta,
    adminMeta: meta.adminMeta,
    authoringMeta: meta.authoringMeta,
    aiContext: meta.aiContext,
    storyMeta: meta.storyMeta,
  };
}

export function emptyStation(id: string, number: number): RiddleEntry {
  return {
    id,
    number,
    position_lat: 0,
    position_lng: 0,
    polylineString: '',
    imagePath: '',
    ...buildDraftStationAssetPaths(id),
    iconColorKey: DEFAULT_STATION_VISUAL.iconColorKey,
    riddleType: 'text',
    solutionInputType: 'text',
    acceptedAnswers: emptyAcceptedAnswers(),
    ...localeMap(emptyRiddleLocale),
  };
}

export function emptyDraft(): TourDraft {
  const slug = createId('tour');
  const now = Date.now();
  return {
    draftId: slug,
    createdAt: now,
    updatedAt: now,
    tour: emptyTour(slug),
    stations: [],
    recordedRoute: [],
    storyline: { markdown: '', updatedAt: 0, chat: [] },
  };
}
