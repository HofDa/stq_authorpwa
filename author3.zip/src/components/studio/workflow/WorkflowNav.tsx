import { Icon } from '../Icon';
import type { StudioWorkflowSection, WorkflowStatus } from './workflowTypes';

interface SectionDef {
  key: StudioWorkflowSection;
  label: string;
  icon: 'grid' | 'map-pin' | 'sparkles' | 'route' | 'phone';
}

/**
 * Visual order matches the natural authoring flow: shape the plan, write the
 * story, lay down the stations, walk the route, then preview what the tourist
 * will see.
 */
const SECTIONS: SectionDef[] = [
  { key: 'plan', label: 'Plan', icon: 'grid' },
  { key: 'story', label: 'Story', icon: 'sparkles' },
  { key: 'stations', label: 'Stations', icon: 'map-pin' },
  { key: 'route', label: 'Route', icon: 'route' },
  { key: 'preview', label: 'Preview', icon: 'phone' },
];

interface Props {
  activeSection: StudioWorkflowSection;
  onSectionChange: (section: StudioWorkflowSection) => void;
  /**
   * Optional per-section badge. Wired up in later PRs once the per-section
   * readiness model lands.
   */
  statusBySection?: Partial<Record<StudioWorkflowSection, WorkflowStatus>>;
}

export function WorkflowNav({
  activeSection,
  onSectionChange,
  statusBySection,
}: Props) {
  return (
    <nav
      role="tablist"
      aria-label="Studio workflow"
      className="studio-view-nav"
    >
      {SECTIONS.map((def) => (
        <SectionChip
          key={def.key}
          icon={def.icon}
          label={def.label}
          active={activeSection === def.key}
          status={statusBySection?.[def.key] ?? 'none'}
          onClick={() => onSectionChange(def.key)}
        />
      ))}
    </nav>
  );
}

function SectionChip({
  icon,
  label,
  active,
  status,
  onClick,
}: {
  icon: SectionDef['icon'];
  label: string;
  active: boolean;
  status: WorkflowStatus;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={`studio-view-chip${active ? ' studio-view-chip--active' : ''}`}
    >
      <Icon name={icon} size={13} />
      <span>{label}</span>
      {status !== 'none' && (
        <span
          className={`studio-view-chip-dot studio-view-chip-dot--${status}`}
          aria-label={statusLabel(status)}
        />
      )}
    </button>
  );
}

function statusLabel(status: Exclude<WorkflowStatus, 'none'>): string {
  switch (status) {
    case 'ready':
      return 'Ready';
    case 'attention':
      return 'Needs attention';
    case 'empty':
      return 'Empty';
  }
}
